var a = document.getElementById("menu-info");
var b = document.getElementById("menu");

a.addEventListener('click',()=>{
	b.classList.toggle("show");
	
})